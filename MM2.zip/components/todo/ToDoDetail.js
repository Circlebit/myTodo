import React from 'react';
import { 
  View, 
  Text, 
  StyleSheet,
  Switch,
  CheckBox,
} from 'react-native';
import PropTypes from 'prop-types';

import Datastore from 'react-native-local-mongodb';
const db = new Datastore({ filename: 'asyncStorageKey', autoload: true });

const styles = StyleSheet.create({
  container: {
    flexDirection: "row",
    flex: 1,
    backgroundColor: '#fff',
    borderColor: 'black',
    borderStyle: 'solid',
    borderWidth: 1,
    borderRadius: 15,
    //width: 310,
    margin: "5%",
    overflow: "hidden",
  },
  SwitchView: {
    flex: 0.3,
  },
  checkbox: {
    display: "flex",
    borderColor: 'red',
    borderStyle: 'solid',
    borderWidth: 1,
    width: 40,
    height: 50,
    flex: 0.2,
  },
  text: {
    display: "flex",
    // borderColor: 'blue',
    // borderStyle: 'solid',
    // borderWidth: 1,
    flex: 0.7,
    textAlignVertical: "center",
  },
  textRed: {
    color: "red",
    display: "flex",
    // borderColor: 'blue',
    // borderStyle: 'solid',
    // borderWidth: 1,
    flex: 0.7,
    textAlignVertical: "center",
    fontWeight: "500",
    backgroundColor: "#FFEEEE",
  },

});
export default class ToDoDetail extends React.Component {
  state = {
    checked: this.props.done || true,
    title: "Default Text ToDoDetail",
  }

  componentWillMount(){
      this.setState({checked: this.props.done ? true: false});
    db.loadDatabase(()=> {

      db.find({ _id: this.props.navigation.state.params.itemId }, (err, docs) => {
        // docs is an array containing documents Mars, Earth, Jupiter
        // If no document is found, docs is equal to []
        if (err){
          console.log(err);
        } else {
          if (docs.length > 0){ 
            foundDoc = docs[0];
            this.setState({ todo: foundDoc, title: foundDoc.title });
          } else {
            console.log("Did not find entry");
            console.log(this.props.navigation.state.params.itemId);
          }
          // console.log("docs in rerender");
          // console.log(docs);
        }
      });
    })

  }

  changeValue = event => {
    this.setState({checked: !this.state.checked});
  }

  removeToDo = () => {
    console.log("reached removeToDo");
    db.remove({ _id: this.state.todo._id }, {}, (err, numRemoved) => {
      // numRemoved = 1
      console.log("after remove");
      this.goBackList();
      console.log(this)
    });
  }

  goBackList = () => {
    this.props.navigation.goBack();
    this.props.navigation.state.params.passedRerender();
  }

  render() {
    //this.props
    // console.log("ToDoDetail this.props");
    // console.log(this.props);
    // console.log("ToDoDetail this.state");
    // console.log(this.state);

            
    return (
        <View style={styles.container}>
          {/* <Switch style={styles.checkbox} value={this.state.checked} onValueChange={this.changeValue.bind()}/> */}
          <CheckBox style={styles.checkbox} value={this.state.checked} onValueChange={this.changeValue.bind()}/>
          <Text style={this.state.checked ? styles.textGrey : styles.text}> {this.props.title || this.state.todo && this.state.todo.title} </Text>
          <Text style={styles.textRed} onPress={this.removeToDo.bind()}> Delete </Text>
        </View>
    );
  }
}

ToDoDetail.propTypes = {
  title: PropTypes.string,
  done: PropTypes.bool,

}
