import React from 'react';
import { 
  View, 
  Text, 
  StyleSheet,
  Switch,
  CheckBox,
} from 'react-native';
import PropTypes from 'prop-types';

const styles = StyleSheet.create({
  container: {
    flexDirection: "row",
    flex: 1,
    backgroundColor: '#fff',
    borderColor: 'black',
    borderStyle: 'solid',
    borderWidth: 1,
    width: 210,
  },
  SwitchView: {
    flex: 0.3,
  },
  checkbox: {
    display: "flex",
    borderColor: 'red',
    borderStyle: 'solid',
    borderWidth: 1,
    width: 40,
    height: 50,
    flex: 0.2
  },
  text: {
    display: "flex",
    // borderColor: 'blue',
    // borderStyle: 'solid',
    // borderWidth: 1,
    flex: 0.7,
    textAlignVertical: "center",

  },
  textGrey: {
    color: "grey",
    display: "flex",
    // borderColor: 'blue',
    // borderStyle: 'solid',
    // borderWidth: 1,
    flex: 0.7,
    textAlignVertical: "center",
  },

});
export default class ToDoSingle extends React.Component {
  state = {
    checked: this.props.done || true,
    title: "Text bei Checkbox",
  }

  componentWillMount(){
      this.setState({checked: this.props.done ? true: false});

  }

  changeValue = event => {
    this.setState({checked: !this.state.checked});
  }

  render() {
    //this.props
            
    return (
        <View style={styles.container}>
          {/* <Switch style={styles.checkbox} value={this.state.checked} onValueChange={this.changeValue.bind()}/> */}
          <CheckBox style={styles.checkbox} value={this.state.checked} onValueChange={this.changeValue.bind()}/>
          <Text style={this.state.checked ? styles.textGrey : styles.text}> {this.props.title || this.state.title} </Text>
        </View>
    );
  }
}

ToDoSingle.propTypes = {
  title: PropTypes.string,
  done: PropTypes.bool,

}
