import React from 'react';
import { 
  View, 
  Text, 
  StyleSheet,
  TextInput,
  Button,
} from 'react-native';

import Datastore from 'react-native-local-mongodb';
const db = new Datastore({ filename: 'asyncStorageKey', autoload: true });


const styles = StyleSheet.create({
  container: {
    flexDirection: "row",
    flex: 1,
    backgroundColor: '#fff',
    borderColor: 'black',
    borderStyle: 'solid',
    borderWidth: 1,
    width: 210,
  },
  input: {
    height: 40,
    flex: 9,
    padding: 4,
  },
  button: {
    flex: 4,
  }

});


export default class NewTodo extends React.Component {
  state = {
    title: "",
  }

  ButtonClicked = () => {
    console.log("Clicked " + this.state.title);

    if (this.state.title != ""){

      let doc = { 
        title: this.state.title
      };
  
      db.insert(doc, (err, newDoc) => {   // Callback is optional
        if (err){
          console.log(err);
        } else {
          console.log(newDoc);
          this.setState({title: ""});
          this.props.passedRerender();
        }
      // newDoc is the newly inserted document, including its _id
      // newDoc has no key called notToBeSaved since its value was undefined
      });
    }
  }

  render() {
    //this.props
            
    return (
        <View style={styles.container}>
          <TextInput
            style={styles.input}
            placeholder="New Todo"
            value={this.state.title}
            onChangeText={(title) => this.setState({title})}
          />
          <Button style={styles.button} title=" + " onPress={this.ButtonClicked.bind()}/>
        </View>
    );
  }
}